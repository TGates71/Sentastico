<?php defined("SYSPATH") or die("No direct script access.") ?>
<p class="success">
  Your Gallery 3 install is complete.
</p>

