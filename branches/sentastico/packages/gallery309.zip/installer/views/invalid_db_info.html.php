<?php defined("SYSPATH") or die("No direct script access.") ?>
<h1> Uh oh! </h1>
<p class="error">
  We were unable to connect to your MySQL server with the username and
  password that you provided.  Please go back and try again!
</p>
