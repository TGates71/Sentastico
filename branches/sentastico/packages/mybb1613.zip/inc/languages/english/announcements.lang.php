<?php
/**
 * MyBB 1.6 English Language Pack
 * Copyright 2010 MyBB Group, All Rights Reserved
 * 
 * $Id: announcements.lang.php 5297 2010-12-28 22:01:14Z Tomm $
 */

$l['nav_announcements'] = "Forum Announcement";
$l['announcements'] = "Announcement";
$l['forum_announcement'] = "Forum Announcement: {1}";
$l['error_invalidannouncement'] = "The announcement specified is invalid.";

$l['announcement_edit'] = "Edit this announcement";
$l['announcement_qdelete'] = "Delete this announcement";
$l['announcement_quickdelete_confirm'] = "Are you sure you want to delete this announcement?";

?>