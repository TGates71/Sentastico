<?php
/**
 * MyBB 1.6 English Language Pack
 * Copyright 2010 MyBB Group, All Rights Reserved
 * 
 * $Id$
 */

/* Uncomment the lines below to use these language strings rather than the help documents set in the database */

/* 
// Help Section 1
$l['s1_name'] = "User Maintenance";
$l['s1_desc'] = "Basic instructions for maintaining a forum account.";

// Help Section 2
$l['s2_name'] = "Posting";
$l['s2_desc'] = "Posting, replying, and basic usage of forum.";
*/
?>