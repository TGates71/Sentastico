<?php
/**
 * MyBB 1.6 English Language Pack
 * Copyright 2010 MyBB Group, All Rights Reserved
 * 
 * $Id: showteam.lang.php 5297 2010-12-28 22:01:14Z Tomm $
 */

$l['nav_showteam'] = "Forum Team";
$l['forum_team'] = "Forum Team";
$l['moderators'] = "Moderators";
$l['mod_username'] = "Username";
$l['mod_forums'] = "Forum(s)";
$l['mod_email'] = "Email";
$l['mod_pm'] = "PM";
$l['uname'] = "Username";
$l['email'] = "Email";
$l['pm'] = "PM";

$l['group_leaders'] = "Leader(s)";
$l['group_members'] = "Member(s)";

$l['no_members'] = "No members in this group";

$l['error_noteamstoshow'] = "There are no forum staff to be shown.";
?>