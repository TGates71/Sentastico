Sentastico
==========

Sentastico is an open-source package installation tool which will quickly and effortlessly copy a wide range of open-source web scripts to your hosting space and then re-direct you to the installer to enable you to personalize your setup! By using Sentastico you save time and bandwidth by not needing to upload large web scripts to your hosting space. 
