  ==========================================================
                      4images Readme
  ==========================================================

  4images - Image Gallery Management System
  Scriptversion: 1.7.11
  Copyright: (C) 2002-2012 Jan Sorgalla
  Email: jan@4homepages.de
  Web: http://www.4homepages.de


  Lizenz / Licence:
  ----------------------------
  Die Lizenzbestimmungen finden Sie in der Datei
  "docs/Lizenz.deutsch.txt"
  ********************************************************
  Please see the "docs/Licence.english.txt" file


  Online-Lizenzshop / Get a License:
  ----------------------------
  Wenn Sie 4images f�r nicht private Zwecke nutzen m�chten
  oder Sie den Copyright-Vermerk im Fu� der Galerie entfernen
  m�chten, erwerben Sie bitte hier die entsprechende Lizenz:
  http://www.4homepages.de/4images/order.php
  ********************************************************
  If you want use 4images for non-private and commercial 
  purposes or if you want to remove the copyright text in
  the footer of the gallery, please get your license here:
  http://www.4homepages.de/4images/order.php


  Installation:
  ----------------------------
  Eine Installationsanleitung finden Sie in der
  Datei "docs/Installation.deutsch.txt"
  ********************************************************
  Please see the "docs/Installation.english.txt" file


  FAQ:
  ----------------------------
  Bei Problemen kontaktieren Sie bitte den FAQ-Bereich in
  unserem Support-Forum:
  http://www.4homepages.de/forum/index.php?board=14.0
  ********************************************************
  If you have problems, see the FAQ section in our
  support forum:
  http://www.4homepages.de/forum/index.php?board=14.0


  Download:
  ----------------------------
  Die neueste Version von 4images kann unter http://www.4homepages.de
  heruntergeladen werden.
  ********************************************************
  You can get the newest version of 4images at http://www.4homepages.de


  Support:
  ----------------------------
  Das Supportforum finden Sie unter http://www.4homepages.de/forum
  ********************************************************
  There is a support forum under http://www.4homepages.de/forum
