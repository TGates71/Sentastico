<?php
 Header("Location: http://www.craftysyntax.com/mobile.php");
 ?>