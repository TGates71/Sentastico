<body marginheight=0 marginwidth=0 leftmargin=0 topmargin=0 bgcolor="<?php echo $midbackcolor; ?>" background="<?php echo $midbackground; ?>">
 <br><br><br>
	<center>
 
<table><tr><td><?php echo $department_a['whilewait']; ?></td></tr></table>

 <br><br> 
 <table cellpadding=0 cellspacing=0 border=0>
   <tr>
    <td width=1 bgcolor=000000><img src=images/blank.gif width=1 height=1></td>
    <td width=284 bgcolor=000000><img src=images/blank.gif width=1 height=1></td>
    <td width=2 bgcolor=000000><img src=images/blank.gif width=2 height=1></td>
   </tr>
   <tr>
    <td width=1 bgcolor=000000><img src=images/blank.gif width=1 height=1></td>    
    <td><img src=themes/operator_top/connecting.gif width=284 height=58 border=0></td>
    <td width=2 bgcolor=000000><img src=images/blank.gif width=2 height=1></td>
   </tr>
   <tr>
    <td width=1 bgcolor=000000><img src=images/blank.gif width=1 height=2></td>
    <td width=284 bgcolor=000000><img src=images/blank.gif width=1 height=2></td>
    <td width=2 bgcolor=000000><img src=images/blank.gif width=2 height=2></td>
   </tr>  
  </table>
</center>
</body>