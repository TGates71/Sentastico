<?php


namespace Ip\Exception;


class Dispatcher extends \Ip\Exception {}