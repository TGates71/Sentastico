<?php


namespace Ip\Exception;


class Permission extends \Ip\Exception {}
