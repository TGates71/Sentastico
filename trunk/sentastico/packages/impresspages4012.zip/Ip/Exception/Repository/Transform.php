<?php


namespace Ip\Exception\Repository;


class Transform extends \Ip\Exception\Repository {}