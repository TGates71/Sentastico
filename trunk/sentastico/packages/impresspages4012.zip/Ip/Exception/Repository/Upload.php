<?php


namespace Ip\Exception\Repository;


class Upload extends \Ip\Exception\Repository {}
