<?php


namespace Ip\Exception\Repository\Upload;


class ForbiddenFileExtension extends \Ip\Exception\Repository\Upload {}
