<?php

namespace Ip\Exception;

class View extends \Ip\Exception {}