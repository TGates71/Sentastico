$(document).ready(function() {
    "use strict";
    $('input[name="login"]').focus();

});
