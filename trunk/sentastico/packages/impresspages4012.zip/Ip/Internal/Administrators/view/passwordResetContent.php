<p><?php _e('To reset your password follow the link below:', 'Ip-admin') ?></p>

<a href="<?php echo $link ?>"><?php echo esc($link) ?></a>

<p><?php _e('You will then be able to reset your password.', 'Ip-admin') ?></p>
