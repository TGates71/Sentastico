<h1><?php _e('Configuration', 'Ip-admin') ?></h1>
<?php echo $form->render() ?>
