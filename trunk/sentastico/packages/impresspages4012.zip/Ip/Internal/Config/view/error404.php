<?php echo ipRenderWidget('Heading', array('title' => $title)); ?>
<?php echo ipRenderWidget('Text', array('text' => $text)); ?>
