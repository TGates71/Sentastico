<div style="<?php echo $style; ?>">
    <iframe style="<?php echo $iframeStyle ?>" src="<?php echo $url ?>" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
</div>
