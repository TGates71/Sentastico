<?php echo ipView('video.php', $this->getVariables()) ?>
