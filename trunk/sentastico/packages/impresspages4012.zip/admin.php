<?php

include __DIR__ . '/index.php';
