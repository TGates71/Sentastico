Original translations that were downloaded from impresspages.org or Transifex.

DO NOT MODIFY FILES IN THIS FOLDER, instead put your modifications in file/translations/override folder.
