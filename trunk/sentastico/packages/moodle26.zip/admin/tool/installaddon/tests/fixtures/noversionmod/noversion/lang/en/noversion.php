<?php

$string['pluginversion'] = 'Activity module with no version.php';
