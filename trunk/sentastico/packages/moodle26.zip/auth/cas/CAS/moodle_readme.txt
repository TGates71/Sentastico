Description of phpCAS 1.3.2 library import

* downloaded from http://downloads.jasig.org/cas-clients/php/current/

iarenaza
