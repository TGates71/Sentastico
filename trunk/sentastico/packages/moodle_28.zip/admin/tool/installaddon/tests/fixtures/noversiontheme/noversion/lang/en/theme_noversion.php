<?php

$string['pluginversion'] = 'A theme with no version.php';
