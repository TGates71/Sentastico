<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_LAST_RUN_OLD', 'It has been over 30 days since the extended security checks were last performed. Please re-run the extended security checks under Tools -&gt; Security Checks.');
?>
