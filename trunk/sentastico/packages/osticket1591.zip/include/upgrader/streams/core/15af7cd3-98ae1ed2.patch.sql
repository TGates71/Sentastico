/*
 * @version=1.6RC1-4
 * 
 * Stage RC2 for 1.6RC5 upgrade
 */

UPDATE `%TABLE_PREFIX%config`
    SET `ostversion`='1.6 RC1-4';
