<?php

$at_adminpage = $_SERVER['PHP_SELF'];

if ($radminsuper == 1) {
    adminmenu("$at_adminpage?module=AutoTheme&op=main", "AutoTheme", "autotheme.gif");
}

?>
