// UK lang variables

tinyMCELang['lang_insert_advhr_desc']    = 'Vlo�it/editovat vodorovn� odd�lova�'
tinyMCELang['lang_insert_advhr_width']   = '���ka';
tinyMCELang['lang_insert_advhr_size']    = 'V��ka';
tinyMCELang['lang_insert_advhr_noshade'] = 'Nest�novat';