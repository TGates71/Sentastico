// DE lang variables

tinyMCELang['lang_insert_advhr_desc']    = 'Horizontale Linie einf&uuml;gen / bearbeiten'
tinyMCELang['lang_insert_advhr_width']   = 'Breite';
tinyMCELang['lang_insert_advhr_size']    = 'H&ouml;he';
tinyMCELang['lang_insert_advhr_noshade'] = 'Keinen Schatten';
