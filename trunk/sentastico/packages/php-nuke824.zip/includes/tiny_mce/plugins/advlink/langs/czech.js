// CZ lang variables

tinyMCELang['lang_insert_link_target_same'] = 'Otev��t ve stejn�m okn�/r�mu';
tinyMCELang['lang_insert_link_target_parent'] = 'Otev��t v rodi�ovsk�m okn�/r�mu';
tinyMCELang['lang_insert_link_target_top'] = 'Otev��t v nejvy���m r�mu (p�ep�e v�echny r�my)';
tinyMCELang['lang_insert_link_target_blank'] = 'Otev��t v nov�m okn�';
tinyMCELang['lang_insert_link_target_named'] = 'Otev��t v okn�';
tinyMCELang['lang_insert_link_popup'] = 'JS-Popup';
tinyMCELang['lang_insert_link_popup_url'] = 'Popup URL';
tinyMCELang['lang_insert_link_popup_name'] = 'N�zev okna';
tinyMCELang['lang_insert_link_popup_return'] = 'insert \'return false\'';
tinyMCELang['lang_insert_link_popup_scrollbars'] = 'Uk�zat posuvn�ky';
tinyMCELang['lang_insert_link_popup_statusbar'] = 'Uk�zat stavov� ��dek';
tinyMCELang['lang_insert_link_popup_toolbar'] = 'Uk�zat ovl. li�tu';
tinyMCELang['lang_insert_link_popup_menubar'] = 'Uk�zat menu';
tinyMCELang['lang_insert_link_popup_location'] = 'Uk�zat li�tu um�st�n�';
tinyMCELang['lang_insert_link_popup_resizable'] = 'Prom�nn� velikost okna';
tinyMCELang['lang_insert_link_popup_size'] = 'Velikost';
tinyMCELang['lang_insert_link_popup_position'] = 'Um�st�n� (X/Y)';
tinyMCELang['lang_insert_link_popup_missingtarget'] = 'Vlo�te n�zev c�le nebo vyberte jinou volbu.';