// French lang variables by Laurent Dran

tinyMCELang['lang_insert_link_target_same'] = 'Ouvre dans la fen&#281;tre / Cadre(frame)';
tinyMCELang['lang_insert_link_target_parent'] = 'Ouvre dans fen&#281;tre parente / Cadres(frame)';
tinyMCELang['lang_insert_link_target_top'] = 'Ouvre dans le Top frame (remplace toutes les cadres(frames))';
tinyMCELang['lang_insert_link_target_blank'] = 'Ouvre dans la fen&#281;tre';
tinyMCELang['lang_insert_link_target_named'] = 'Ouvre dans la fen&#281;tre';
tinyMCELang['lang_insert_link_popup'] = 'JS-Popup';
tinyMCELang['lang_insert_link_popup_url'] = 'URL de la Popup';
tinyMCELang['lang_insert_link_popup_name'] = 'Nom de la fen&#281;tre';
tinyMCELang['lang_insert_link_popup_return'] = 'Insert \'return false\'';
tinyMCELang['lang_insert_link_popup_scrollbars'] = 'Montrer la barre de d&eacute;filement ';
tinyMCELang['lang_insert_link_popup_statusbar'] = 'Montrer la barre d\'&eacute;tat';
tinyMCELang['lang_insert_link_popup_toolbar'] = 'Montrer la barre d\'outils';
tinyMCELang['lang_insert_link_popup_menubar'] = 'Montrer la barre du menu';
tinyMCELang['lang_insert_link_popup_location'] = 'Montre la barre d\'adresse';
tinyMCELang['lang_insert_link_popup_resizable'] = 'Fabriquer une fen&#281;tre redimensionnable';
tinyMCELang['lang_insert_link_popup_size'] = 'Taille';
tinyMCELang['lang_insert_link_popup_position'] = 'Position (X/Y)';
tinyMCELang['lang_insert_link_popup_missingtarget'] = 'Veuillez ins&eacute;rer un nom pour la cible ou choisissez une autre option.';
