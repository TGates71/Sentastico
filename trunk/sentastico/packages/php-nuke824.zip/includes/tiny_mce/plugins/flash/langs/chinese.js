// Simplified Chinese lang variables contributed by cube316 (cube316@etang.com)

tinyMCELang['lang_insert_flash']      = '����/�༭ Flash��Ӱ';
tinyMCELang['lang_insert_flash_file'] = 'Flash�ļ�(.swf)';
tinyMCELang['lang_insert_flash_size'] = '�ߴ�';
tinyMCELang['lang_insert_flash_list'] = 'Flash files';
