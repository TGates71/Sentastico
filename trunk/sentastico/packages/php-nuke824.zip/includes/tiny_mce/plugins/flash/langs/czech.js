// UK lang variables

tinyMCELang['lang_insert_flash']      = 'Vlo�it/editovat Flash Movie';
tinyMCELang['lang_insert_flash_file'] = 'Flash soubor (.swf)';
tinyMCELang['lang_insert_flash_size'] = 'Velikost';