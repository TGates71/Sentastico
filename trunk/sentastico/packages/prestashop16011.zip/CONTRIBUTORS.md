GitHub contributors:
--------------------------------
(d)oekia
123monsite-regis
Adonis Karavokyros
Adrien
Agence CINS
Aleksander Palyan
Alex Even
Alexander Grosul
Alexander Otchenashev
Alexandra Even
AlexEven
Alexey Svistunov
alexey-svistunov
Alfakom-MK
Alfonso Jimenez
anat
Anatole
Andrew
antoniofr
AntonLejon
Arnaud Lemercier
axi
Axome
Balestrino
bellini13
Benjamin PONGY
Bersam Karbasion
BigZ
BluTiGeS
Bruno Leveque
bumbu
Burhan
Caleydon Media
cam.lafit
Captain FLAM
Captain-FLAM
ccauw
cedricfontaine
cedricgeffroy
Chen.Zhidong
Chris
Chris Gurk
ChristopheBoucaut
CINS
cippest
cmouleyre
codvir
Comkwatt
Corentin Delcourt
Cosmin Hutanu
Cedric Mouleyre
Damien Metzger
DamienMetzger
Damon Skelhorn
danidomen
Daniel
Daniele Giachino
danoosh
Danoosh Mir
David Gasperoni
David-Julian BUCH
Davy Rolink
DevNet
Dh42
Dimitrios Karvounaris
Dinis Lage
djbuch
djfm
dlage
doekia
DOEO
Dragan Skrbic
Dream me up
dreammeup
DrySs
DrySs'
dSevere
Dustin
Dvir Julius
Dvir-Julius
edamart
Edouard Gaulue
elationbase
eleazar
Emilien Puget
emilien-puget
emily-d
Eric Le Lay
erickturcios
Fabio Chelly
fchellypresta
Felipe Uribe
fetis
Florian Kwakkenbos
fram
Francois Gaillard
Francois-Marie de Jouvencel
Fran�ois Gaillard
Gabriel Schwardy
Gaelle ITZKOVITZ
Gamesh
ggedamed
Gordon Coubrough
gr4devel
Granger Kevin
Gregory Roussac
gRoussac
Gregoire Belorgey
Guillaume DELOINCE
Guillaume Lafarge
Ha!*!*y
ha99y
hiousi
indesign47
iNem0o
ironwo0d
ITBpro.com
Ivan
ivancasasempere
J. Danse
janisVincent
Javsmile
JEAN
jeanbe
jeckyl
Jerome Nadaud
jeromenadaud
jessylenne
Joan Juvanteny
joemartin247
Joep Hendrix
Jonadabe
Jonathan Danse
Jonathan SAHM
Jorge Vargas
joseantgv
Julien
Julien Bouchez
Julien Bourdeau
julienbourdeau
Jachym Tousek
Kevin Granger
kiropowered
kpodemski
Krystian Podemski
Kevin Dunglas
ldecoker
Lesley Paone
LOIC ROSSET ltd
Luca T.
Lucas CERDAN
LucasC
Lyo Nick
LyoNick
Leo
M-Mommsen
Madef
Madman
Mainmich
makk1ntosh
marcinsz101
Marco Cervellin
matiasiglesias
Mats Rynge
MatthieuB
Maxence
Maxime
mchelh
mchojnacki
Michel Courtade
Mickael Desgranges
Mikael Blotin
Mikko Hellsing
Milow
Mingsong Hu
minic studio
misthero
montes
MustangZhong
natrim
neemzy
nezenmoins
Nicolas Sorosac
Niklas Ekman
Niko Wicaksono
Nils-Helge Garli Hegvik
NinjaOfWeb
Nino Uzelac
nturato
oleacorner
Otto Nascarella
Panagiotis Tigas
Patanock
Patrick Mettraux
Pavel Novitsky
Per Lejontand
Peter Schaeffer
peterept
PhpMadman
Pierre
Piotr Kaczor
Piotr Moćko
PrestaEdit
PrestaLab
prestamodule
PrestanceDesign
prestarocket
Prestaspirit
Priyank Bolia
Pronux
pxls
quadrateam
Quentin Leonetti
Quentin Montant
Quetzacoalt91
Racochejl
Rafael Cunha
Raphael Malie
raulgundin
rGaillard
Rhys
Rimas Kudelis
robert
romainberger
runningz
Remi Gaillard
s-duval
Sacha
Sacha Froment
sadlyblue
sagaradonis
Samir Shah
Samy Rabih
Sarah Lorenzini
Seb
Seynaeve
sfroment42
shaffe-fr
Shagshag
Shipow
shudrum
sjousse
sLorenzini
smartdatasoft
soufyan
soware
Staging
Stanislav Yordanov
Stephan Obadia
Steven "SDF" Sulley
Studio Kiwik
Sumh
Sylvain Gougouzian
Sylvain WITMEYER
Sebastien
Sebastien Bareyre
Sebastien Bocahu
tchauviere
Thibaud Chauviere
thoma202
Thomas
Thomas Blanc
Thomas N
Thomas Nabord
Threef
timsit
tmackay
TMMeilleur
Tom Panier
Tomasz Slominski
tucoinfo
Tung Dao
vAugagneur
Vincent Augagneur
Vincent Schoener
Vincent Terenti
vinvin27
vinzter
web-plus
Xavier
Xavier Borderie
Xavier POITAU
xKnut
yanngarras
Yoozio
zimmi1
ZiZuu.com
Zollner Robert

SVN contributors:
--------------------------------
aFolletete
aKorczak
aNiassy
bLeveque
bMancone
dMetzger
dSevere
fBrignoli
Francois Gaillard
fSerny
gBrunier
gCharmes
gPoulain
hAitmansour
jBreux
jmCollin
jObregon
lBrieu
lCherifi
lLefevre
mBertholino
mDeflotte
mMarinetti
nPellicari
rGaillard
rMalie
rMontagne
sLorenzini
sThiebaut
tDidierjean
vAugagneur
vChabot
vKham
vSchoener
