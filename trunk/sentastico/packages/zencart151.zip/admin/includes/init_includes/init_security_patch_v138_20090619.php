<?php
/**
 * @package patches
 * @copyright Copyright 2003-2010 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: init_security_patch_v138_20090619.php 15882 2010-04-11 16:37:54Z wilt $
 */
/**
 * Security Patch v138 20090619
 * @package patches
 */
/////// NOTE: THIS FILE NO LONGER RELEVANT in v1.3.9 and higher.  PLEASE DELETE FROM YOUR SERVER.