<?php
/**
 * @package linkpoint_api_payment_module
 * @copyright Copyright 2003-2009 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: linkpoint_review.php 14139 2009-08-10 13:46:02Z wilt $
 */

define('FILENAME_LINKPOINT_REVIEW', 'linkpoint_review');
define('BOX_CUSTOMERS_LINKPOINT_REVIEW', 'FirstData/Linkpoint CC Review');
