<?php
//
// +----------------------------------------------------------------------+
// |zen-cart Open Source E-commerce                                       |
// +----------------------------------------------------------------------+
// | Copyright (c) 2003 The zen-cart developers                           |
// |                                                                      |
// | http://www.zen-cart.com/index.php                                    |
// |                                                                      |
// | Portions Copyright (c) 2003 osCommerce                               |
// +----------------------------------------------------------------------+
// | This source file is subject to version 2.0 of the GPL license,       |
// | that is bundled with this package in the file LICENSE, and is        |
// | available through the world-wide-web at the following url:           |
// | http://www.zen-cart.com/license/2_0.txt.                             |
// | If you did not receive a copy of the zen-cart license and are unable |
// | to obtain it through the world-wide-web, please send a note to       |
// | license@zen-cart.com so we can mail you a copy immediately.          |
// +----------------------------------------------------------------------+
//  $Id: zones.php 1105 2005-04-04 22:05:35Z birdbrain $
//

define('HEADING_TITLE', 'Zones');

define('TABLE_HEADING_COUNTRY_NAME', 'Country');
define('TABLE_HEADING_ZONE_NAME', 'Zones');
define('TABLE_HEADING_ZONE_CODE', 'Code');
define('TABLE_HEADING_ACTION', 'Action');

define('TEXT_INFO_EDIT_INTRO', 'Please make any necessary changes');
define('TEXT_INFO_ZONES_NAME', 'Zones Name:');
define('TEXT_INFO_ZONES_CODE', 'Zones Code:');
define('TEXT_INFO_COUNTRY_NAME', 'Country:');
define('TEXT_INFO_INSERT_INTRO', 'Please enter the new zone with its related data');
define('TEXT_INFO_DELETE_INTRO', 'Are you sure you want to delete this zone?');
define('TEXT_INFO_HEADING_NEW_ZONE', 'New Zone');
define('TEXT_INFO_HEADING_EDIT_ZONE', 'Edit Zone');
define('TEXT_INFO_HEADING_DELETE_ZONE', 'Delete Zone');
?>