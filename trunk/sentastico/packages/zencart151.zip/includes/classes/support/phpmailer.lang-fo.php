<?php
/**
 * PHPMailer language file.  
 * Faroese Version [language of the Faroe Islands, a Danish dominion]
 * This file created: 11-06-2004
 * Supplied by D�vur S�rensen [www.profo-webdesign.dk]
 */

$PHPMAILER_LANG = array();

$PHPMAILER_LANG["provide_address"] = 'T� skal uppgeva minst ' .
                                     'm�ttakara-emailadressu(r).';
$PHPMAILER_LANG["mailer_not_supported"] = ' er ikki supportera�.';
$PHPMAILER_LANG["execute"] = 'Kundi ikki �tf�ra: ';
$PHPMAILER_LANG["instantiate"] = 'Kuni ikki instantiera mail funkti�n.';
$PHPMAILER_LANG["authenticate"] = 'SMTP feilur: Kundi ikki g��kenna.';
$PHPMAILER_LANG["from_failed"] = 'fylgjandi Fr�/From adressa miseydna�ist: ';
$PHPMAILER_LANG["recipients_failed"] = 'SMTP Feilur: Fylgjandi ' .
                                       'm�ttakarar miseydna�ust: ';
$PHPMAILER_LANG["data_not_accepted"] = 'SMTP feilur: Data ikki g��kent.';
$PHPMAILER_LANG["connect_host"] = 'SMTP feilur: Kundi ikki kn�ta samband vi� SMTP vert.';
$PHPMAILER_LANG["file_access"] = 'Kundi ikki tilganga f�lu: ';
$PHPMAILER_LANG["file_open"] = 'F�lu feilur: Kundi ikki opna f�lu: ';
$PHPMAILER_LANG["encoding"] = '�kend encoding: ';
?>