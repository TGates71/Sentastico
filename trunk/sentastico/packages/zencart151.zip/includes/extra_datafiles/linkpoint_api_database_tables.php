<?php
/**
 * @package linkpoint_api_payment_module
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @copyright Portions Copyright 2003 Jason LeBaron 
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: linkpoint_api_database_tables.php 4612 2006-09-26 08:03:05Z drbyte $
 */


  define('TABLE_LINKPOINT_API', DB_PREFIX . 'linkpoint_api');

?>