<p><strong>To assist you in navigating our site, we have provided the following map.</strong></p>
<p>If you are having difficulty in locating something on our site, please visit our <a href="<?php echo zen_href_link(FILENAME_CONTACT_US, '', 'SSL'); ?>">Contact Us </a> page and let us know! </p>
