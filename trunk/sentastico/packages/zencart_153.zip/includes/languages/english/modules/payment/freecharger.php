<?php
/**
 * @package payment_modules
 * @copyright Copyright 2003-2011 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: freecharger.php 18697 2011-05-04 14:35:20Z wilt $
 */

  define('MODULE_PAYMENT_FREECHARGER_TEXT_TITLE', 'Free Order');
  define('MODULE_PAYMENT_FREECHARGER_TEXT_DESCRIPTION', 'There is no charge for this order.');
  define('MODULE_PAYMENT_FREECHARGER_TEXT_EMAIL_FOOTER', 'There is no charge for this order.');
