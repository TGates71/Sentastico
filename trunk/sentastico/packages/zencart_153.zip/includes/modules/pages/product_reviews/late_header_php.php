<?php
/**
 * Product Reviews late header
 * 
 * @package page
 * @copyright Copyright 2003-2006 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: late_header_php.php 2982 2006-02-07 07:56:41Z birdbrain $
 */

$breadcrumb->add(NAVBAR_TITLE, zen_href_link(FILENAME_PRODUCT_REVIEWS, zen_get_all_get_params()));
?>